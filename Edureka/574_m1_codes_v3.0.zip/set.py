A={1,2,3,3}

print(A)