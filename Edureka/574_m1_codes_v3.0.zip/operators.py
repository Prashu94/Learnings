# Arithmetic operators
a=50
b=40
print(a+b)

print(a-b)

print(a*b)

print(a/b)

print(a%b)

print(a//b)

print(a**b)


#Assignment Operators

a=30
b=30
a=b
print(a)

a+=b
print(a)

a-=b
print(a)

a*=b
print(a)

a/=b
print(a)

a**=b
print(a)

a//=b
print(a)

# Comparison Operator
a=50
b=100
print(a==b)
print(a!=b)
print(a>b)
print(a<b)
print(a>=b)
print(a<=b)

#Logical Operators

a=10
b=50

print(a and b)
print(a or b)
print(not a)


#Bitwise Operators
a=10
b=35

print(a&b)
print(a|b)
print(a^b)
print(~a)
print(a<<2)
print(a>>b)

#Identity Operators

a=[1,3,5,7,'Python']
a=b
print(b is a)

print(a is not b)

# Membership Operators

list1=[1,10,100,"Data Science"]
print(30 in list1)
print(20 not in list1)

